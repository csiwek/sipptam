#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
sipptam.tas.Tas.py

Object which represents a the Test Automation Slave.

@author:  Luis Martin Gil
@contact: luis.martin.gil@indigital.net
@organization: INdigital Telecom, Inc.
@copyright: INdigital Telecom, Inc. 2013
'''


class Tas(object):
    '''
    '''
    def init(self):
        print 'todo'


if __name__ == '__main__':
    '''
    Main execution thread.
    '''
    print 'todo'
